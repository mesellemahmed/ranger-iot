# RANGER-IoT — Proposed Final Research-Question Contract

These RQs are the recommended manuscript structure because each one has
a closed evidence chain.

## RQ1 — Resilience

How do static coded dissemination, neighbor-assisted recovery, and
adaptive dissemination differ in rekey completion and convergence under
loss?

Evidence:
STEP7A + STEP7B1 + STEP7B2.

Expected conclusion:
Recovery and adaptive mechanisms can substantially outperform Static in
lossy settings, but their relative benefit depends on context.


## RQ2 — External validity

How stable are the comparative conclusions across topology, group size,
loss regime, and embedded Cooja layouts?

Evidence:
STEP7B1 + STEP7B2 + STEP7B3.

Expected conclusion:
The results are topology- and scale-sensitive; no universal protocol
winner is supported.


## RQ3 — Coding realism

Do conclusions obtained under the idealized k-of-n abstraction remain
valid when reconstruction uses the actual byte-level Reed-Solomon codec?

Evidence:
STEP7C1 + STEP7C2 + STEP7C3 + STEP7D2-C-B.

Expected conclusion:
For the frozen bridge contexts, member acceptance/reconstruction
decisions are exactly preserved by real RS byte-level decoding.


## RQ4 — Security

Under which explicit assumptions does the rekey protocol preserve
authorization, replay/freshness, post-revocation key confidentiality,
and recovery authorization across epochs?

Evidence:
STEP7D2-B + STEP7D2-C-A.

Expected conclusion:
The bounded reference model verifies the specified temporal properties,
while finite structural analysis extends implementation-derived evidence
across multiple tree shapes and revocation configurations.


## RQ5 — Security boundary

What confidentiality guarantee ceases to be meaningful after later
exposure of a former authorized holder's historical state?

Evidence:
counterexample preservation + causal audit + temporal contract.

Expected conclusion:
Post-revocation secrecy of newly generated keys must be distinguished
from everlasting confidentiality of historical keys legitimately held
before later compromise/exposure.
