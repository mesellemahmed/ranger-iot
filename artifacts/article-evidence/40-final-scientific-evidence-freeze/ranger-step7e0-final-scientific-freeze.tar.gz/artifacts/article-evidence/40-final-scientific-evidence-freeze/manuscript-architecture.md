# RANGER-IoT — Final Manuscript Architecture

## 1. Introduction
- constrained IoT rekeying problem;
- reliability/security tension;
- why static dissemination is insufficient;
- contributions stated with bounded wording.

## 2. Background and Related Work
- group-key management;
- LKH;
- reliable dissemination;
- erasure coding;
- recovery/adaptation;
- formal verification of rekey protocols.

## 3. System and Threat Model
- group manager;
- members;
- revoked members;
- lossy network;
- trusted/compromised states;
- attacker knowledge;
- explicit exclusions.

## 4. RANGER-IoT Design
- Static;
- Recovery;
- Adaptive-V2;
- authorization remains LKH;
- transport/coding separated from key authorization.

## 5. Coding Layer
- historical idealized k-of-n abstraction;
- real systematic RS GF(256);
- codec parameters;
- C/Python equivalence;
- exact boundary between redundancy and security.

## 6. Experimental Methodology
- frozen seeds;
- topologies;
- scales;
- packet loss;
- Cooja layouts;
- pairing;
- exact tests;
- bootstrap;
- Holm correction;
- stopping rules.

## 7. Experimental Results
### 7.1 Original scenario hardening
### 7.2 Topology/scale/loss external validity
### 7.3 Cooja external validity
### 7.4 Static vs Recovery
### 7.5 Static vs Adaptive
### 7.6 Adaptive vs Recovery context dependence
### 7.7 Cost and latency trade-offs

## 8. Coding-Realism Validation
- Python RS;
- C differential;
- Cooja/RPL bytes;
- 420-run bridge;
- 16380 exact member-level decisions.

## 9. Formal Security Analysis
### 9.1 Authorization/transport abstraction
### 9.2 Multi-epoch LKH model
### 9.3 Preserved counterexamples
### 9.4 Causal reclassification
### 9.5 17-property temporal contract
### 9.6 Negative mutation control
### 9.7 Finite structural generalization

## 10. Discussion
- when Recovery dominates;
- when Adaptive is useful;
- why context dependence matters;
- historical-key exposure boundary;
- relationship between formal and empirical evidence.

## 11. Threats to Validity
- finite topology set;
- fixed 8-mote Cooja scale;
- symbolic cryptography;
- finite structural audit not arbitrary-N;
- idealized historical network model;
- bridge methodology;
- no Tamarin liveness claim.

## 12. Reproducibility
- Docker;
- frozen seeds;
- evidence manifests;
- source hashes;
- pinned formal environment;
- exact commands.

## 13. Conclusion
- bounded conclusions only;
- no universal winner;
- evidence convergence across simulation, embedded emulation,
  byte-level codec validation, and formal analysis.
